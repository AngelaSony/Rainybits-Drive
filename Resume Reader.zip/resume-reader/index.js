const fs = require("fs");
const http = require("http");
const path = require("path");

const server = http.createServer((request, response) => {
  const method = request.method.toLowerCase();
  const url = request.url;

  if (method === "get" && url === "/") {
    response.writeHead(200, { "Content-Type": "text/html" });
    return fs
      .createReadStream(path.join("public", "index.html"))
      .pipe(response);
  } else if (method === "post" && url === "/") {
    const contentLength = parseInt(request.headers["content-length"]);
    response.setHeader("Content-Type", "application/json");

    if (isNaN(contentLength) || contentLength <= 0) {
      response.statusCode = 411;
      return response.end(JSON.stringify({ status: false }));
    }

    const name = "file." + request.headers.extension;
    const stream = fs.createWriteStream(name);

    stream.on("error", (error) => {
      console.error(error);
      response.statusCode = 400;
      response.end(JSON.stringify({ status: false }));
    });

    request.pipe(stream);

    request.on("end", () => {
      stream.close(() => {
        fs.readFile(name, async (error, data) => {
          response.statusCode = 200;
          response.end(JSON.stringify({ data: data.toString(), status: true }));
        });
      });
    });
  } else {
    response.writeHead(303, { location: "/" });
    return response.end();
  }
});

server.listen(process.env.PORT || 3000);
